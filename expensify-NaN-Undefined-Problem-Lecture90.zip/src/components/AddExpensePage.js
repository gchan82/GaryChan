import React from 'react';
import { BrowserRouter, Route, Switch, Link, NavLink } from 'react-router-dom';


const AddExpensePage = (props) => (
    <div>expense component</div>
);


export default AddExpensePage;