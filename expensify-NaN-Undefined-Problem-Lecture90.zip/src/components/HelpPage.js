import React from 'react';
import { BrowserRouter, Route, Switch, Link, NavLink } from 'react-router-dom';

const HelpPage = () => (
    <div>Help component</div>
);


export default HelpPage;