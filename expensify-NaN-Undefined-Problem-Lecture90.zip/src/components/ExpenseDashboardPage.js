import React from 'react';
import { BrowserRouter, Route, Switch, Link, NavLink } from 'react-router-dom';


const ExpenseDashboardPage = () => (
    <div>This is from my dashboard component</div>
);


export default ExpenseDashboardPage;