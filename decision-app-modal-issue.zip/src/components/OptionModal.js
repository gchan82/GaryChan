import React from 'react';
import Modal from 'react-modal';

const OptionModal = () => {
    <div>
        this is OptionModal
    </div>
};

export default OptionModal;