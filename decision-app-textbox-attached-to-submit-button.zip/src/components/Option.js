import React from 'react';

const Option = (props) => (
    <div className="widget-header">
        {" "}
        {props.optionText}
        <button
            className="button button--remove"
            onClick={e => {
                props.handleDeleteOneItem(props.optionText);
            }}
        >
            Remove
  </button>
    </div>
);
export default Option;