const firstName = fullName => fullName.split(" ")[0];

console.log(firstName("gary chan"));

/* const square = function(x) {
  return x * x;
};

const squareArrow = x => x * x;

console.log(squareArrow(8)); */
