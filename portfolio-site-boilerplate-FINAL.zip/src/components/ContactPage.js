import React from 'react';
import { BrowserRouter, Route, Switch, Link, NavLink } from 'react-router-dom';

const ContactPage = () => (
    <div>ContactPage</div>
);

export default ContactPage;