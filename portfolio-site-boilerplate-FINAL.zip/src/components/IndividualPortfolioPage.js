import React from 'react';
import { BrowserRouter, Route, Switch, Link, NavLink } from 'react-router-dom';

const IndividualPortfolioPage = (props) => (
    <div>
        <h1>IndividualPortfolioPage</h1>
        <p>Individual item id:{props.match.params.id}</p>
    </div>
);

export default IndividualPortfolioPage;