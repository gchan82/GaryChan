import React from 'react';
import Option from './Option';

const Options = props => (
    <div>
        <button onClick={props.deleteOptions}>Delete All</button>
        {props.options.length === 0 && <p>Please add option to get started.</p>}
        {props.options.map(option => (
            <Option
                key={option}
                optionText={option}
                handleDeleteOneItem={props.handleDeleteOneItem}
            />
        ))}

    </div>
);

export default Options;