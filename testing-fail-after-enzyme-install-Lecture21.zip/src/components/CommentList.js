import React from "react";

export default () => {
  return <div>Comment List</div>;
};
