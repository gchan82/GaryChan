import React from 'react';

export default () => {
  return <div>Comment Box</div>;
};