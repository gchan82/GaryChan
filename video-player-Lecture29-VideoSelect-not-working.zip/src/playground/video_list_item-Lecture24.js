import React from 'react';

const VideoListItem = (props) => {
    return <li>Video</li>
};

export default VideoListItem;