import React from 'react';

export default () => {
	return <div>I'm the app component</div>;
};
