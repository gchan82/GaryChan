import React, { Component } from 'react'

export default class delete-later extends Component {
  render() {
    return (
      <div>
        
      </div>
    )
  }
}
