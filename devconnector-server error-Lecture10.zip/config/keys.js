module.exports = {
	mongoURI: 'mongodb://gary:gary123@ds117615.mlab.com:17615/devconnector',
};
