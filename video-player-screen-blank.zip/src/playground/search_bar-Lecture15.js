//import React from 'react';
import React, { Component } from 'react';
//const Component = React.Component;


// const SearchBar = () => {
//     return <input />;
// };

//class SearchBar extends React.Component {
class SearchBar extends Component {
    render() {
        return <input />
    }
}

export default SearchBar;