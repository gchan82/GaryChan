//import library
import React from 'react';
import { Text } from 'react-native';

// component
const Header = () => (
  <Text>Albums</Text>
);

export default Header;