function average(a, b) {
  return (a + b) / 2;
}

console.log(Average(2, 3));

